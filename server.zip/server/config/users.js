export const USERS = {
  "admin-key": { role: "admin", userId: 1 },
  "manager-key": { role: "manager", userId: 2 },
  "employee-key": { role: "employee", userId: 3 }
};