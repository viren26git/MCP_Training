import crypto from "crypto";

const SECRET = "super-secret-key";

export function generateToken(user) {
  return crypto
    .createHmac("sha256", SECRET)
    .update(JSON.stringify(user))
    .digest("hex");
}