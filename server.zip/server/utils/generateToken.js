import { generateToken } from "./token.js";

// same users as config
const users = [
  { role: "admin", userId: 1 },
  { role: "manager", userId: 2 },
  { role: "employee", userId: 3 }
];

users.forEach(user => {
  const token = generateToken(user);
  console.log(`${user.role.toUpperCase()} TOKEN:`, token);
});

