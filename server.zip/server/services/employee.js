let employees = [
  { id: 1, name: "Viren", role: "admin" },
  { id: 2, name: "Rahul", role: "manager" },
  { id: 3, name: "Anita", role: "employee" }
];

export function getEmployee(id) {
  return employees.find(e => e.id === id);
}

export function createEmployee(data) {
  const newEmp = { id: employees.length + 1, ...data };
  employees.push(newEmp);
  return newEmp;
}

export function updateEmployee(id, name) {
  const emp = employees.find(e => e.id === id);
  if (emp) emp.name = name;
  return emp;
}

export function deleteEmployee(id) {
  employees = employees.filter(e => e.id !== id);
  return { message: "Deleted" };
}
