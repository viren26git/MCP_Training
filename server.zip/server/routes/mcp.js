import express from "express";
import { authenticate } from "../middleware/auth.js";
import {
  getEmployee,
  createEmployee,
  deleteEmployee,
  updateEmployee
} from "../services/employee.js";

const router = express.Router();

router.post("/", async (req, res) => {
  const { method, params = {} } = req.body;

  const user = authenticate(req);

  if (user.error) {
    return res.json({ success: false, error: user.error });
  }

  if (method === "employee/get") {
    const result = getEmployee(user, params.id);
    return res.json({ success: !result?.error, data: result });
  }

  if (method === "employee/create") {
    const result = createEmployee(user, params);
    return res.json({ success: !result?.error, data: result });
  }

  if (method === "employee/delete") {
    const result = deleteEmployee(user, params.id);
    return res.json({ success: !result?.error, data: result });
  }

  if (method === "employee/update") {
    const result = updateEmployee(user, params.id, params.name);
    return res.json({ success: !result?.error, data: result });
  }

  res.json({ error: "Unknown method" });
});

export default router;