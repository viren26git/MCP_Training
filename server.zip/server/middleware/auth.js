import { USERS } from "../config/users.js";
import { generateToken } from "../utils/token.js";

export function authenticate(req) {
  const apiKey = req.headers["x-api-key"];
  const token = req.headers["x-token"];

  const user = USERS[apiKey];
  if (!user) return { error: "Invalid API Key" };

  const validToken = generateToken(user);

  if (token !== validToken) {
    return { error: "Invalid Token" };
  }

  return user;
}