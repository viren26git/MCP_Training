import express from "express";
import { authenticate } from "./middleware/auth.js";
import {
  getEmployee,
  createEmployee,
  updateEmployee,
  deleteEmployee
} from "./services/employee.js";

const app = express();
app.use(express.json());

let employees = [];   // empty array

app.post("/employees", (req,res) =>{
  const emp ={
    id: employees.length +1,
    ...req.body
  };

  employees.push(emp)   // take all data from the url and store into the empty array

  res.json(emp);
})

/*
// Get - all users which are allowed
app.get("/employees/:id", (req, res) => {
  const user = authenticate(req);
  if (user.error) return res.json(user);

  const result = getEmployee(Number(req.params.id));
  res.json(result);
});


// Create - for admin only
app.post("/employees", (req, res) => {
  const user = authenticate(req);
  if (user.error) return res.json(user);

  if (user.role !== "admin") {
    return res.json({ error: "Only admin can create" });
  }

  const result = createEmployee(req.body);
  res.json(result);
});


// update - admin only
app.put("/employees/:id", (req, res) => {
  const user = authenticate(req);
  if (user.error) return res.json(user);

  if (user.role !== "admin") {
    return res.json({ error: "Only admin can update" });
  }
  const result = updateEmployee(Number(req.params.id), req.body.name);
  res.json(result);
});

// delete admin - only
app.delete("/employees/:id", (req, res) => {
  const user = authenticate(req);
  if (user.error) return res.json(user);

  if (user.role !== "admin") {
    return res.json({ error: "Only admin can delete" });
  }

  const result = deleteEmployee(Number(req.params.id));
  res.json(result);
}); */

app.listen(4000, () => {
  //console.log("Role-based CRUD server running");
  console.log(" MCP for logging is running !!")
});
