const metrics ={
    totalRequests:0,
    success:0,
    errors:0,
    avgLatency:0
};

export function recordRequest(latency,success){
    metrics.totalRequests++;

    if(success)
    {
        metrics.success++;
    }
    else {
        metrics.errors++
    }

    metrics.avgLatency = (metrics.avgLatency + latency) /2 ;
}

export function getMetrics(){
    return metrics;
}